import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { AnalyticsCard } from "@/components/ui/analytics-card";
import { CourseCard } from "@/components/ui/course-card";
import { useAuth } from "@/hooks/use-auth";
import type { Course, Enrollment } from "@shared/schema";

export default function Dashboard() {
  const { user } = useAuth();

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
  });

  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const enrolledCourses = enrollments.map(enrollment => 
    courses.find(course => course.id === enrollment.courseId)
  ).filter((course): course is Course => !!course);

  const completedCourses = enrollments.filter(e => e.completed).length;
  const inProgressCourses = enrollments.filter(e => !e.completed).length;
  const averageProgress = enrollments.length > 0 ? 
    enrollments.reduce((acc, curr) => acc + (curr.progress ?? 0), 0) / enrollments.length : 
    0;

  const categoryData = enrolledCourses.reduce((acc, course) => {
    acc[course.category] = (acc[course.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const pieData = Object.entries(categoryData).map(([name, value]) => ({
    name,
    value,
  }));

  return (
    <div className="min-h-screen bg-background p-6">
      <header className="max-w-7xl mx-auto flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-primary">Learning Dashboard</h1>
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="outline">Course Catalog</Button>
          </Link>
          <span className="text-muted-foreground">{user?.username}</span>
        </div>
      </header>

      <main className="max-w-7xl mx-auto space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <AnalyticsCard
            title="Completed Courses"
            value={completedCourses}
            total={enrollments.length}
          />
          <AnalyticsCard
            title="In Progress"
            value={inProgressCourses}
            total={enrollments.length}
          />
          <AnalyticsCard
            title="Course Categories"
            value={Object.keys(categoryData).length}
            total={enrollments.length}
            data={pieData}
          />
        </div>

        <section>
          <h2 className="text-2xl font-semibold mb-6">Your Courses</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {enrolledCourses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                enrollment={enrollments.find((e) => e.courseId === course.id)}
              />
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}