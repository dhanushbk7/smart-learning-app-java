import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { CourseCard } from "@/components/ui/course-card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Course, Enrollment } from "@shared/schema";

export default function HomePage() {
  const { user } = useAuth();

  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
  });

  const { data: recommendations = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses/recommendations"],
  });

  const enrollMutation = useMutation({
    mutationFn: async (courseId: number) => {
      const res = await apiRequest("POST", `/api/enroll/${courseId}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments"] });
    },
  });

  return (
    <div className="min-h-screen bg-background p-6">
      <header className="max-w-7xl mx-auto flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-primary">EduAI</h1>
        <div className="flex items-center gap-4">
          <Link href="/dashboard">
            <Button variant="outline">Dashboard</Button>
          </Link>
          <span className="text-muted-foreground">Welcome, {user?.username}</span>
        </div>
      </header>

      <main className="max-w-7xl mx-auto space-y-12">
        {recommendations.length > 0 && (
          <section>
            <h2 className="text-2xl font-semibold mb-6">Recommended for You</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recommendations.map((course) => (
                <CourseCard
                  key={course.id}
                  course={course}
                  enrollment={enrollments.find((e) => e.courseId === course.id)}
                  onEnroll={(courseId) => enrollMutation.mutate(courseId)}
                />
              ))}
            </div>
          </section>
        )}

        <section>
          <h2 className="text-2xl font-semibold mb-6">All Courses</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                enrollment={enrollments.find((e) => e.courseId === course.id)}
                onEnroll={(courseId) => enrollMutation.mutate(courseId)}
              />
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
