import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./dialog";
import { Button } from "./button";
import { Textarea } from "./textarea";
import { Star, StarHalf } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { CourseRating } from "@shared/schema";

type RatingDialogProps = {
  courseId: number;
  trigger?: React.ReactNode;
};

export function RatingDialog({ courseId, trigger }: RatingDialogProps) {
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: existingRating } = useQuery<CourseRating>({
    queryKey: [`/api/courses/${courseId}/ratings/user`],
  });

  const submitRating = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/courses/${courseId}/ratings`, {
        rating,
        feedback,
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/courses/${courseId}/ratings`] });
      queryClient.invalidateQueries({ queryKey: [`/api/courses/${courseId}/ratings/user`] });
      setOpen(false);
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || <Button variant="outline">Rate Course</Button>}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Rate this Course</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="flex justify-center space-x-2">
            {[1, 2, 3, 4, 5].map((value) => (
              <button
                key={value}
                className={`text-2xl ${
                  value <= rating ? "text-yellow-400" : "text-gray-300"
                }`}
                onClick={() => setRating(value)}
              >
                <Star className="h-8 w-8" />
              </button>
            ))}
          </div>
          <Textarea
            placeholder="Share your thoughts about this course..."
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
          />
          <Button
            className="w-full"
            onClick={() => submitRating.mutate()}
            disabled={rating === 0 || submitRating.isPending}
          >
            Submit Rating
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
