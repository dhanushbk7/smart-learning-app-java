import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "./card";
import { Button } from "./button";
import { Progress } from "./progress";
import { RatingDialog } from "./rating-dialog";
import { useQuery } from "@tanstack/react-query";
import type { Course, Enrollment, CourseRating } from "@shared/schema";
import { Star } from "lucide-react";

type CourseCardProps = {
  course: Course;
  enrollment?: Enrollment;
  onEnroll?: (courseId: number) => void;
};

export function CourseCard({ course, enrollment, onEnroll }: CourseCardProps) {
  const { data: ratings = [] } = useQuery<CourseRating[]>({
    queryKey: [`/api/courses/${course.id}/ratings`],
  });

  const averageRating = ratings.length > 0
    ? ratings.reduce((acc, curr) => acc + curr.rating, 0) / ratings.length
    : 0;

  return (
    <Card className="overflow-hidden">
      <img 
        src={course.imageUrl} 
        alt={course.title} 
        className="w-full h-48 object-cover"
      />
      <CardHeader>
        <CardTitle className="text-lg">{course.title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">{course.description}</p>
        <div className="mt-2 flex items-center justify-between">
          <span className="inline-block bg-primary/10 text-primary px-2 py-1 rounded-full text-sm">
            {course.category}
          </span>
          {ratings.length > 0 && (
            <span className="flex items-center text-sm text-muted-foreground">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
              {averageRating.toFixed(1)} ({ratings.length})
            </span>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-2">
        {enrollment ? (
          <>
            <Progress value={enrollment.progress} className="w-full" />
            <RatingDialog courseId={course.id} />
          </>
        ) : (
          <Button 
            onClick={() => onEnroll?.(course.id)} 
            className="w-full"
          >
            Enroll Now
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}