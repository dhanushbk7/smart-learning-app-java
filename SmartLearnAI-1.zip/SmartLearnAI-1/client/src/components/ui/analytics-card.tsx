import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Progress } from "./progress";
import { ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

type AnalyticsCardProps = {
  title: string;
  value: number;
  total: number;
  data?: Array<{ name: string; value: number }>;
};

const COLORS = ['#4285F4', '#34A853', '#FBBC05', '#EA4335'];

export function AnalyticsCard({ title, value, total, data }: AnalyticsCardProps) {
  const percentage = Math.round((value / total) * 100) || 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-2xl font-bold">{value}</p>
            <Progress value={percentage} className="w-[60px]" />
          </div>
          {data && (
            <div className="h-[100px] w-[100px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data}
                    innerRadius={25}
                    outerRadius={40}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {data.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
