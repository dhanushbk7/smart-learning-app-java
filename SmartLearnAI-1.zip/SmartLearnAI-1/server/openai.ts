import OpenAI from "openai";
import type { Course, Enrollment } from "@shared/schema";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface RecommendationResponse {
  recommended_course_ids: number[];
}

export async function getRecommendations(
  courses: Course[],
  enrollments: Enrollment[],
): Promise<Course[]> {
  try {
    const enrolledCourseIds = enrollments.map((e) => e.courseId);
    const availableCourses = courses.filter(
      (course) => !enrolledCourseIds.includes(course.id),
    );

    if (availableCourses.length === 0) return [];

    const userContext = {
      enrolled_courses: enrollments.map((e) => {
        const course = courses.find((c) => c.id === e.courseId);
        return {
          title: course?.title,
          category: course?.category,
          progress: e.progress,
          completed: e.completed,
        };
      }),
      available_courses: availableCourses.map((c) => ({
        id: c.id,
        title: c.title,
        category: c.category,
      })),
    };

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content:
            "You are a course recommendation system. Based on the user's enrolled courses and available courses, recommend up to 3 courses that would be most relevant for their learning journey. Return the course IDs in a JSON array.",
        },
        {
          role: "user",
          content: JSON.stringify(userContext),
        },
      ],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      console.error("Empty response from OpenAI");
      return [];
    }

    const result = JSON.parse(content) as RecommendationResponse;
    const recommendedIds = result.recommended_course_ids || [];

    return availableCourses.filter((course) =>
      recommendedIds.includes(course.id),
    );
  } catch (error) {
    console.error("Failed to get recommendations:", error);
    return [];
  }
}