import { users, courses, enrollments, courseRatings, type User, type InsertUser, type Course, type Enrollment, type CourseRating, type InsertCourseRating } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getEnrollments(userId: number): Promise<Enrollment[]>;
  enrollInCourse(userId: number, courseId: number): Promise<Enrollment>;
  updateProgress(enrollmentId: number, progress: number): Promise<Enrollment>;

  // New methods for ratings
  createCourseRating(rating: InsertCourseRating): Promise<CourseRating>;
  getCourseRatings(courseId: number): Promise<CourseRating[]>;
  getUserCourseRating(userId: number, courseId: number): Promise<CourseRating | undefined>;
  updateCourseRating(id: number, rating: Partial<InsertCourseRating>): Promise<CourseRating>;

  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async getEnrollments(userId: number): Promise<Enrollment[]> {
    return await db
      .select()
      .from(enrollments)
      .where(eq(enrollments.userId, userId));
  }

  async enrollInCourse(userId: number, courseId: number): Promise<Enrollment> {
    const [enrollment] = await db
      .insert(enrollments)
      .values({
        userId,
        courseId,
        progress: 0,
        completed: false,
      })
      .returning();
    return enrollment;
  }

  async updateProgress(enrollmentId: number, progress: number): Promise<Enrollment> {
    const [enrollment] = await db
      .update(enrollments)
      .set({
        progress,
        completed: progress === 100,
      })
      .where(eq(enrollments.id, enrollmentId))
      .returning();

    if (!enrollment) {
      throw new Error("Enrollment not found");
    }

    return enrollment;
  }

  async createCourseRating(rating: InsertCourseRating): Promise<CourseRating> {
    const [newRating] = await db
      .insert(courseRatings)
      .values(rating)
      .returning();
    return newRating;
  }

  async getCourseRatings(courseId: number): Promise<CourseRating[]> {
    return await db
      .select()
      .from(courseRatings)
      .where(eq(courseRatings.courseId, courseId));
  }

  async getUserCourseRating(userId: number, courseId: number): Promise<CourseRating | undefined> {
    const [rating] = await db
      .select()
      .from(courseRatings)
      .where(
        and(
          eq(courseRatings.userId, userId),
          eq(courseRatings.courseId, courseId)
        )
      );
    return rating;
  }

  async updateCourseRating(id: number, rating: Partial<InsertCourseRating>): Promise<CourseRating> {
    const [updatedRating] = await db
      .update(courseRatings)
      .set(rating)
      .where(eq(courseRatings.id, id))
      .returning();
    return updatedRating;
  }
}

export const storage = new DatabaseStorage();