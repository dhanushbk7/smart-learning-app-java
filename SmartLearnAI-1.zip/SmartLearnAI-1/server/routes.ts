import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { getRecommendations } from "./openai";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Get all courses
  app.get("/api/courses", async (_req, res) => {
    const courses = await storage.getCourses();
    res.json(courses);
  });

  // Get course recommendations
  app.get("/api/courses/recommendations", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const courses = await storage.getCourses();
    const enrollments = await storage.getEnrollments(req.user.id);

    try {
      const recommendations = await getRecommendations(courses, enrollments);
      res.json(recommendations);
    } catch (error) {
      console.error("Failed to get recommendations:", error);
      res.status(500).json({ message: "Failed to get course recommendations" });
    }
  });

  // Get user enrollments
  app.get("/api/enrollments", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const enrollments = await storage.getEnrollments(req.user.id);
    res.json(enrollments);
  });

  // Enroll in a course
  app.post("/api/enroll/:courseId", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const courseId = parseInt(req.params.courseId);
    const enrollment = await storage.enrollInCourse(req.user.id, courseId);
    res.json(enrollment);
  });

  // Update progress
  app.patch("/api/enrollments/:enrollmentId/progress", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const enrollmentId = parseInt(req.params.enrollmentId);
    const progress = parseInt(req.body.progress);
    const enrollment = await storage.updateProgress(enrollmentId, progress);
    res.json(enrollment);
  });

  // New rating endpoints
  app.get("/api/courses/:courseId/ratings", async (req, res) => {
    const courseId = parseInt(req.params.courseId);
    const ratings = await storage.getCourseRatings(courseId);
    res.json(ratings);
  });

  app.post("/api/courses/:courseId/ratings", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const courseId = parseInt(req.params.courseId);

    const rating = await storage.createCourseRating({
      userId: req.user.id,
      courseId,
      rating: req.body.rating,
      feedback: req.body.feedback,
    });

    res.status(201).json(rating);
  });

  app.get("/api/courses/:courseId/ratings/user", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const courseId = parseInt(req.params.courseId);

    const rating = await storage.getUserCourseRating(req.user.id, courseId);
    if (!rating) {
      return res.status(404).json({ message: "Rating not found" });
    }

    res.json(rating);
  });

  const httpServer = createServer(app);
  return httpServer;
}